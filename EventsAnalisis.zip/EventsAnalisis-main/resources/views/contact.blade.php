@extends("layouts.main")

@section('title', 'Produtos')

@section('content')

    <h1>Hello contact</h1>


    
@endsection